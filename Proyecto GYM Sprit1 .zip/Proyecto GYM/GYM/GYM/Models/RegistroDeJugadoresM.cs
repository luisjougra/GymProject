﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class RegistroDeJugadoresM
    {
        [Display(Name = "Ingrese un nombre"),
        Required(ErrorMessage = "Debe ingresar un codigo"),
        MinLength(6, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(25, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Nombre { get; set; }

        [Display(Name = "Ingrese su primer apellido"),
        Required(ErrorMessage = "Debe ingresar un apellido"),
        MinLength(4, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(25, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string PrimerApellido { get; set; }

        [Display(Name = "Ingrese su segundo apellido"),
        Required(ErrorMessage = "Debe ingresar un apellido"),
        MinLength(1, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(25, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string SegundoApellido { get; set; }

        [Display(Name = "Ingrese su numero de identificacion"),
        Required(ErrorMessage = "Debe ingresar un apellido"),
        MinLength(7, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(30, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string NumeroIdentificacion { get; set; }

        [Display(Name = "Correo Electronico"),
        Required(ErrorMessage = "Debe ingresar un Correo Electronico Valido"),
        StringLength(30, ErrorMessage = "Debe ingresar {1} o menos caracteres"),
        EmailAddress(ErrorMessage = "Debe ingresar un Correo Electronico valido"),
        RegularExpression(@"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$", ErrorMessage = "Caracteres no validos")
        ]
        public string CorreoElectronico { get; set; }

        [Display(Name = "Ingrese una imagen"),
        Required(ErrorMessage = "Debe ingresar una iamgen"),
        ]
        public Byte[]  Fotografia { get; set; }


        [Display(Name = "Ingrese su provincia"),
        Required(ErrorMessage = "Debe ingresar una provincia"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(30, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Provincia { get; set; }

        [Display(Name = "Ingrese su canton"),
        Required(ErrorMessage = "Debe ingresar un canton"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(30, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Canton { get; set; }

        [Display(Name = "Ingrese su Distrito"),
        Required(ErrorMessage = "Debe ingresar un distrito"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(30, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Distrito { get; set; }

        [Display(Name = "Fecha Debud"),
        Required(ErrorMessage = "Debe ingresar una Fecha de Debud"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime FechaDebud { get; set; }

        [Display(Name = "Fecha de ingreso"),
        Required(ErrorMessage = "Debe ingresar una Fecha de ingreso"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Ingreso { get; set; }

        [Display(Name = "Fecha de Insercion"),
        Required(ErrorMessage = "Debe ingresar una Fecha de insercion"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Insercion { get; set; }

        [Display(Name = "Ingrese usuario insercion"),
        Required(ErrorMessage = "Debe ingresar un usuario"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(30, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Usuario_Insercion { get; set; }


        public DateTime Fecha_Modificacion { get; set; }


        public string Usuario_Modificacion { get; set; }

        public RegistroDeJugadoresM() {

        }

        public RegistroDeJugadoresM(string PNombre, string PPrimerApellido, string PSegundoApellido, string PNumeroIdentificacion,
            string PCorreoElectronico, Byte[] PFotografia, string PProvincia, string PCanton, string PDistrito,
            DateTime PFechaDebud, DateTime PFecha_Ingreso, DateTime PFecha_Insercion, string PUsuario_Insercion,
            DateTime PFecha_Modificacion, string PUsuario_Modificacion)
        {
            this.Nombre = PNombre; this.PrimerApellido = PPrimerApellido; this.SegundoApellido = PSegundoApellido;
            this.NumeroIdentificacion = PNumeroIdentificacion; this.CorreoElectronico = PCorreoElectronico; this.Fotografia = PFotografia;
            this.Provincia = PProvincia; this.Canton = PCanton; this.Distrito = PDistrito; this.FechaDebud = PFechaDebud;
            this.Fecha_Ingreso = PFecha_Ingreso; this.Fecha_Insercion = PFecha_Insercion; this.Usuario_Insercion = PUsuario_Insercion;
            this.Fecha_Modificacion = PFecha_Modificacion; this.Usuario_Modificacion = PUsuario_Modificacion;
        }

    }
}