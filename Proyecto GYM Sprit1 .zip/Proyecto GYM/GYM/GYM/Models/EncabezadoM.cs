﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class EncabezadoM
    {
        [Display(Name = "Fecha de Realizacion de Rutina"),
        Required(ErrorMessage = "Debe ingresar una Fecha de Realizacion de Rutina"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime FechaRealizacionRutina { get; set; }

        [Display(Name = "Fecha de Realizacion de Rutina"),
        Required(ErrorMessage = "Debe ingresar una Fecha de Realizacion de Rutina"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime FechaInicioRutina { get; set; }

        [Display(Name = "Fecha Fin Rutina"),
        Required(ErrorMessage = "Debe ingresar una Fecha Fin Rutina"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime FechaFinRutina { get; set; }

        [Display(Name = "Ingrese el Objetivos"),
        Required(ErrorMessage = "Debe ingresar un Objetivos"),
        MinLength(25, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(100, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Objetivos { get; set; }

        [Display(Name = "Fecha Ingreso"),
        Required(ErrorMessage = "Debe ingresar una Fecha de Ingreso"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Ingreso { get; set; }

        [Display(Name = "Fecha Insercion"),
        Required(ErrorMessage = "Debe ingresar una de Fecha Insercion"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Insercion { get; set; }

        [Display(Name = "Ingrese el Usuario Insercion"),
        Required(ErrorMessage = "Debe ingresar un Usuario Insercion"),
        MinLength(25, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(50, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Usuario_Insercion { get; set; }

        [Display(Name = "Fecha Modificacion"),
        Required(ErrorMessage = "Debe ingresar Fecha Modificacion"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Modificacion { get; set; }

        [Display(Name = "Ingrese el Usuario Modificacion"),
        Required(ErrorMessage = "Debe ingresar un Usuario Modificacion"),
        MinLength(25, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(50, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Usuario_Modificacion { get; set; }

        public EncabezadoM() {

        }

        public EncabezadoM(DateTime PFechaRealizacionRutina, DateTime PFechaInicioRutina, DateTime PFechaFinRutina, string PObjetivos,
            DateTime PFecha_Ingreso, DateTime Fecha_Insercion, string PUsuario_Insercion, DateTime PFecha_Modificacion,
             string PUsuario_Modificacion)
        {

        }
    }
}