﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class EmailEncabezado
    {

        public string Nombre_Jugador { get; set; }

        public string Nombre_Instructor { get; set; }

        public string Objetivos { get; set; }

        public string FechaInicioRutina { get; set; }

        public string FechaRealizacionRutina { get; set; }

        public string FechaFinRutina { get; set; }

        public string CorreoElectronico { get; set; }


    }
}