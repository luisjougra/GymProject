﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class DetalleRutinaM
    {
        public string NumeroDeRepeteiciones { get; set; }
        public string NumeroDeDescansos { get; set; }
        public DateTime Fecha_Ingreso { get; set; }

    }
}