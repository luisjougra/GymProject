﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class MaquinaM
    { 
        [Display(Name = "Ingrese El numero del activo"),
        Required(ErrorMessage = "Debe ingresar un numero del activo"),
        MinLength(1, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(10, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string NumeroDeActivo { get; set; }

        [Display(Name = "Ingrese el Estado"),
        Required(ErrorMessage = "Debe ingresar un Estado"),
        MinLength(1, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(1, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Estado { get; set; }

        [Display(Name = "Fecha de adquisicion"),
        Required(ErrorMessage = "Debe ingresar una fecha"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime FechaAdquisicion { get; set; }

        [Display(Name = "Fecha de Insercion"),
        Required(ErrorMessage = "Debe ingresar una fecha"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Insercion { get; set; }

        [Display(Name = "Usuario Insercion"),
        Required(ErrorMessage = "Debe ingresar un Usuario"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(25, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Usuario_Insercion { get; set; }

        [Display(Name = "Fecha de Modificacion"),
        Required(ErrorMessage = "Debe ingresar una fecha"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Modificacion { get; set; }

        [Display(Name = "Usuario Modificacion"),
        Required(ErrorMessage = "Debe ingresar un Usuario"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(25, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Usuario_Modificacion { get; set; }

        public MaquinaM() {

        }

        public MaquinaM(string PCodigo, string PNumeroDeActivo, string PEstado, DateTime PFechaAdquisicion, DateTime PFecha_Insercion, string PUsuario_Insercion, DateTime PFecha_Modificacion, string PUsuario_Modificacion)
        {
            this.NumeroDeActivo = PNumeroDeActivo;
            this.Estado = PEstado;
            this.FechaAdquisicion = PFechaAdquisicion;
            this.Fecha_Insercion = PFecha_Insercion;
            this.Usuario_Insercion = PUsuario_Insercion;
            this.Usuario_Modificacion = PUsuario_Modificacion;
        }

    }
}