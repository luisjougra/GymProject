﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class TipoDeEjercicioM
    {
        [Display(Name = "Ingrese un Ejercicio"),
        Required(ErrorMessage = "Debe ingresar un codigo"),
        MinLength(3, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(25, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string NombreTipoDeEjercicio { get; set; }

        public string Estado { get; set; }

        public DateTime Fecha_Insercion { get; set; }

        public string Usuario_Insercion { get; set; }

        public DateTime Fecha_Modificacion { get; set; }

        public string Usuario_Modificacion { get; set; }
    }
}