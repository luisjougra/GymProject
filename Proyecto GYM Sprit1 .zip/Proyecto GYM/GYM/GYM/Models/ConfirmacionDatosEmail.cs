﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class ConfirmacionDatosEmail
    { 

        public string FromEmail { get; set; }

        public string Nombre { get; set; }

        public string PrimerApellido { get; set; }

        public string SegundoApellido { get; set; }

        public string NumeroIdentificacion { get; set; }

        public string CorreoElectronico { get; set; }

        public string Contrasenia { get; set; }


    }
}