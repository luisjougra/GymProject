﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class EjercicioM
    {
        /// <summary>
        /// Esta es mi modelo EjecicioM
        /// </summary>

        [Display(Name = "El Estado A=Activo, I=Inactivo"),
        Required(ErrorMessage = "Debe ingresar un estado"),
        MinLength(1, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        MaxLength(1, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Estado { get; set; }


        [Display(Name = "Fecha Insercion"),
        Required(ErrorMessage = "Debe ingresar un Usuario"),
        DataType(DataType.Date, ErrorMessage = "Debe ingresar una fecha valida"),
        ]
        public DateTime Fecha_Insercion { get; set; }

        [Display(Name = "El usuario de insercion"),
        Required(ErrorMessage = "Debe ingresar un Usuario"),
        MinLength(5, ErrorMessage = "Debe ingresar un minimo de {1}caracteres"),
        StringLength(50, ErrorMessage = "Debe ingresar {1} o menos caracteres")
        ]
        public string Usuario_Insercion { get; set; }

        public EjercicioM() {

        }

        public EjercicioM( string PEstado, DateTime PFecha_Insercion, string PUsuario_Insercion)
        {
            this.Estado = PEstado;
            this.Fecha_Insercion = PFecha_Insercion;
            this.Usuario_Insercion = PUsuario_Insercion;
        }

    }
}