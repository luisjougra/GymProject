﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GYM.Models
{
    public class RegistroJugadorM
    {
       public int FK_idUsuarios {get;set;}

       public DateTime FechaDebuds { get; set; }
    }
}