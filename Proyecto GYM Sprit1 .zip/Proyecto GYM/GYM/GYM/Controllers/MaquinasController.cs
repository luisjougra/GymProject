﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GYM.BD;

namespace GYM.Controllers
{
    public class MaquinasController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();
        // GET: Maquinas
        public ActionResult Index()
        {   
            List<Maquina> ModeloDB = this.miModeloDB.Maquina.ToList();
            return View(ModeloDB);
        }

        public ActionResult FormularioMaquina()
        {
            ViewBag.ListaTipoDeMaquinaria = this.miModeloDB.ListaTipoDeMaquinaria().ToList();
            return View();
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult FormularioMaquina(Maquina MiInsercion, Maquina Fecha,Maquina Estados,TipoDeMaquinaria idTipoDeMaquinarias)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    var id = idTipoDeMaquinarias.idTipoMaquinaria;
                    MiInsercion.FK_TipoMaquinaria = Convert.ToInt32(id);
                    var Estadoss = Estados.Estado;
                    MiInsercion.Estado = Convert.ToString(Estadoss);
                    var miFecha = Fecha.Fecha_Insercion;
                    miFecha = DateTime.Now;
                    MiInsercion.Fecha_Insercion = miFecha;
                    string nombre;
                    nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                    MiInsercion.Usuario_Insercion = nombre;
                    miModeloDB.Maquina.Add(MiInsercion);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }
            catch
            {
                ViewBag.ListaTipoDeMaquinaria = this.miModeloDB.ListaTipoDeMaquinaria().ToList();
                return View();
            }
        }


        // GET: Maquinas/Details/5
        public ActionResult Details(int id)
        {
            Maquina OBJMaquina = miModeloDB.Maquina.Find(id);
            return View(OBJMaquina);
        }

        // GET: Maquinas/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Maquinas/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Maquinas/Edit/5
        public ActionResult Edit(int id)
        {
            Maquina OBJMaquina = miModeloDB.Maquina.Find(id);
            ViewBag.ListaTipoDeMaquinaria = this.miModeloDB.ListaTipoDeMaquinaria().ToList();
            return View(OBJMaquina);
        }

        // POST: Maquinas/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Maquina MoEditar, Maquina MoUsuario, Maquina Fecha)
        {
            try
            {
                var miFecha = Fecha.Fecha_Modificacion;
                miFecha = DateTime.Now;
                MoEditar.Fecha_Modificacion = miFecha;
                string nombre;
                nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                MoEditar.Usuario_Modificacion = nombre;
                Maquina OBJMaquina = miModeloDB.Maquina.Find(id);
                miModeloDB.Entry(OBJMaquina).CurrentValues.SetValues(MoEditar);
                //Hacer el cmmit de la transaccion
                this.miModeloDB.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                ViewBag.ListaTipoDeMaquinaria = this.miModeloDB.ListaTipoDeMaquinaria().ToList();
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            List<Maquina> OBJMaquina = miModeloDB.Maquina.Where(m => m.idMaquina == id).ToList();
            return View(OBJMaquina);
        }


        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                Maquina OBJMaquina = miModeloDB.Maquina.Find(id);
                miModeloDB.Maquina.Remove(OBJMaquina);
                miModeloDB.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
