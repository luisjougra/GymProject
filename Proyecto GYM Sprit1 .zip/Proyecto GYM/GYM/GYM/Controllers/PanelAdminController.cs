﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GYM.BD;

namespace GYM.Controllers
{
    public class PanelAdminController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();

        public ActionResult Administracion(){
            if (Session["nombreCompleto"] == null)
            {
                return RedirectToAction("Perfil", "PerfilUsuarios");
            }
            else
            {
                string nombre;
                nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                List<Usuarios> OBJUsuarios = miModeloDB.Usuarios.Where(m => m.Nombre == nombre).ToList();
                return View(OBJUsuarios);
            }
        }
    }
}
