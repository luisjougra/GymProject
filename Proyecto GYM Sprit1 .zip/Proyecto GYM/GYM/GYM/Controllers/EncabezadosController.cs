﻿
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using GYM.BD;


namespace ProyectoProgra6.Controllers
{
    public class EncabezadosController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();

        // GET: Encabezados
        public ActionResult Index()
        {
            List<SP_SelectEncabezado1_Result> ObtenerInstructores = this.miModeloDB.SP_SelectEncabezado1().ToList();
            //List<Encabezado> miModelo = this.miModeloDB.Encabezado.ToList();
            // return View(ObtenerInstructores);
            return View(ObtenerInstructores);
        }


        public JsonResult RetornaEncabezados()
        {
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            List<SP_SelectEncabezado1_Result> OBJRetornaEncabezados = this.miModeloDB.SP_SelectEncabezado1().ToList();
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            serializer.MaxJsonLength = 500000000;
            var json = Json(OBJRetornaEncabezados, JsonRequestBehavior.AllowGet);
            json.MaxJsonLength = 500000000;
            return json;


            //return Json(OBJRetornaEncabezados, JsonRequestBehavior.AllowGet);
        }


        public ActionResult DetEncabezado()
        {
            List<SP_selectInstructoress_Result> ObtenerInstructores = this.miModeloDB.SP_selectInstructoress().ToList();
            SelectList list = new SelectList(ObtenerInstructores, "idRegistroDeInstructores", "Nombre");
            ViewBag.Instructores = list;

            List<SP_ObtenerJugador_Result> ObtenerJugador = this.miModeloDB.SP_ObtenerJugador().ToList();
            SelectList lista = new SelectList(ObtenerJugador, "idRegistroJugadores", "Nombre");
            ViewBag.Jugador = lista;


            List<Usuarios> listaUsuarios = this.miModeloDB.Usuarios.ToList();
            ViewBag.ListaUsuarioso = listaUsuarios;
            return View();
        }

        [HttpPost]
        public ActionResult DetEncabezado(Encabezado MiInsercion,Encabezado Fecha, RegistroDeInstructores idInstructor, RegistroJugadores idJugador)
        {

            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    var idJ = idJugador.idRegistroJugadores;
                    MiInsercion.FK_idRegistroJugadores = Convert.ToInt32(idJ);
                    var idI = idInstructor.idRegistroDeInstructores;
                    MiInsercion.FK_idRegistroDeInstructores = Convert.ToInt32(idI);
                    var miFecha = Fecha.Fecha_Insercion;
                    miFecha = DateTime.Now;
                    MiInsercion.Fecha_Insercion = miFecha;
                    string nombre;
                    nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                    MiInsercion.Usuario_Insercion = nombre;
                    miModeloDB.Encabezado.Add(MiInsercion);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("index");
                }
                else {
                    ModelState.AddModelError("", "Error en el modelo.");
                    
                }
                return RedirectToAction("index");

            }
            catch (Exception Error) {
                ModelState.AddModelError("", "Excepcion controlador."+Error);
              //  List<SP_ObtenerInstructor_Result> ObtenerInstructores = this.miModeloDB.SP_ObtenerInstructor().ToList();
                //SelectList list = new SelectList(ObtenerInstructores, "idRegistroDeInstructores", "Nombre");
                //ViewBag.Instructores = list;

                List<SP_ObtenerJugador_Result> ObtenerJugador = this.miModeloDB.SP_ObtenerJugador().ToList();
                SelectList lista = new SelectList(ObtenerJugador, "idRegistroJugadores", "Nombre");
                ViewBag.Jugador = lista;

                return View();
            }
        }

/*
        public ActionResult enviarEmail(int id)
        {
            //Usuarios OBJUsuario = miModeloDB.Usuarios.Find(id);
            //return View(OBJUsuario);
           // SP_SelectEncabezadoCorreoID_Result ObtenerInstructores = miModeloDB.SP_SelectEncabezadoCorreoID(id).FirstOrDefault();
            return View();
           // return View();
        }
        /*
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> enviarEmails(EmailEncabezado model, EmailEncabezado Email)
        {
            if (ModelState.IsValid)
            {
                //Cuerpo del Email
                var body = "<table style='max-width: 600px; padding: 10px; margin:0 auto; border-collapse: collapse;'><tr><td style='background-color: #ecf0f1; text-align: left; padding: 0; background: rgb(242,246,248);" +
                    "background: -moz-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 50%, rgba(181,198,208,1) " +
                    "51%, rgba(224,239,249,1) 100%); background: -webkit-linear-gradient(top, rgba(242,246,248,1) 0%,rgba(216,225,231,1) " +
                    "50%,rgba(181,198,208,1) 51%,rgba(224,239,249,1) 100%); background: linear-gradient(to bottom, rgba(242,246,248,1)" +
                    " 0%,rgba(216,225,231,1) 50%,rgba(181,198,208,1) 51%,rgba(224,239,249,1) 100%); filter: " +
                    "progid:DXImageTransform.Microsoft.gradient( startColorstr='#f2f6f8', endColorstr='#e0eff9',GradientType=0 );'>" +
                    "<ul><li style='color: #e67e22; margin: 0 0 7px; font-size:20px;'>GOLD’S GYM Jordan L.</li></ul></td></tr><tr><td style='padding: 0'>" +
                    "<a  style='padding: 0;  display: block'   href='#'><img width='700px' height='350px' src='http://i1079.photobucket.com/albums/w515/_bolobofree_/gym1.1_zpsme77td3g.jpg' border='0' /></a></td></tr><tr><td style='background-color:" +
                    " #ecf0f1'><div style='color: #34495e; margin: 4% 10% 2%; text-align: justify;font-family: sans-serif'><h2 style='color: #e67e22; margin: 0 0 7px'>Datos del Usuario Encabezado!</h2><ul style='font-size: 15px;  margin: 10px 0'>" +
                  
           /*     var message = new MailMessage();
                string emailDestinatario = Email.CorreoElectronico;
                message.To.Add(new MailAddress(emailDestinatario));
                message.Subject = "Enviado por Jordan GYM";
                message.Body = string.Format(body,
                model.Nombre_Jugador,model.Nombre_Instructor, model.Objetivos, model.FechaInicioRutina, model.FechaRealizacionRutina,model.FechaFinRutina,
                model.CorreoElectronico);
                message.IsBodyHtml = true;

                using (var smtp = new SmtpClient())
                {
                    var credential = new NetworkCredential
                    {
                        UserName = "bolobo1@hotmail.com",  // replace with valid value
                        Password = "JordanLeon1991"  // replace with valid value
                    };
                    smtp.Credentials = credential;
                    smtp.Host = "smtp.live.com";
                    smtp.Port = 587;
                    smtp.EnableSsl = true;
                    await smtp.SendMailAsync(message);
                    return RedirectToAction("index");
                }
            }
            return View(model);
        }*/









        // GET: Encabezados/Details/5
        public ActionResult Details(int id)
        {
            List<SP_SelectEncabezadoID_Result> ObtenerInstructores = this.miModeloDB.SP_SelectEncabezadoID(id).ToList();
            return View(ObtenerInstructores);
        }


        // GET: Encabezados/Edit/5
        public ActionResult Edit(int id)
        {   

            return View();
        }

        // POST: Encabezados/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Encabezados/Delete/5
        public ActionResult Delete(int id)
        {
            List<SP_SelectEncabezadoID_Result> ObtenerInstructores = this.miModeloDB.SP_SelectEncabezadoID(id).ToList();
            return View(ObtenerInstructores);
            //return View();
        }

        // POST: Encabezados/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                Encabezado OBJEncabezado = miModeloDB.Encabezado.Find(id);
                miModeloDB.Encabezado.Remove(OBJEncabezado);
                miModeloDB.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
