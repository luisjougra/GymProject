﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GYM.BD;

namespace GYM.Controllers
{
    public class IniciarSessionController : Controller
    {

        GYMEntities miModeloDB = new GYMEntities();
       
        // GET: InicarSession
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Acceder()
        {
            return View();
        }

        //Método post del loguin(cuando se da click en el botón submit)
        [HttpPost]
        public ActionResult Acceder(Usuarios pModelo)
        {
            Usuarios usuarioBuscar = this.miModeloDB.Usuarios.Where(m => m.CorreoElectronico == pModelo.CorreoElectronico
                && m.Contrasenia == pModelo.Contrasenia)
                .FirstOrDefault();
            if (usuarioBuscar == null)
            {
                //permanecer en index del controlador loguin
                this.ModelState.AddModelError("", "Usuario o contraseña inválidos. Por favor Verifique");
                return View("Acceder");
            }
            else
            {
                ///establecer los datos de sesion para que
                ///cuando el layout consulte por dichos datos
                ///no re-direccione a loguin
                this.Session.Add("logueado", true);
                string nombreCompleto = usuarioBuscar.Nombre;
                int tipoUsuario = Convert.ToInt32(usuarioBuscar.FK_idTipoUsuario);
                this.Session.Add("nombreCompleto", nombreCompleto);
                this.Session.Add("tipoUsuario", tipoUsuario);

                int idUsuarios = Convert.ToInt32(usuarioBuscar.idUsuarios);
                this.Session.Add("idUsuarios", idUsuarios);

                ///agregamos todo el modelo del usuario
                this.Session.Add("datosUsuario", usuarioBuscar);
                ///redireccionar al método
                ///index del controlador home

                int tipoUsuarios;
                tipoUsuarios = Convert.ToInt32(this.Session["tipoUsuario"].ToString());



                

                if (tipoUsuarios == 1) {
                    return RedirectToAction("Administracion", "PanelAdmin");
                }
                if (tipoUsuarios == 2)
                {
                    return RedirectToAction("Administracion2", "PanelAdmin2");
                }

                else
                {
                    return RedirectToAction("Perfil", "PerfilUsuarios");
                }







                
            }
        }


        public ActionResult cerrarSession() {

            this.Session.Add("logueado", false);
            Session["nombreCompleto"] = null;
            return RedirectToAction("Acceder", "IniciarSession");

        }

        


    }
}
