﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using GYM.BD;


namespace GYM.Controllers
{
    public class RegUsuariosController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();

        // GET: RegistroDeInstructores
        public ActionResult Index()
        {
            List<Usuarios> miModelo = this.miModeloDB.Usuarios.ToList();
  
            return View(miModelo);
        }

        public int MaxJsonLength { get; set; }

        public JsonResult RetornaUsuarios()
        {
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            List<Usuarios> OBJUsuarios = this.miModeloDB.Usuarios.ToList();
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            serializer.MaxJsonLength = 500000000;
            var json = Json(OBJUsuarios, JsonRequestBehavior.AllowGet);
            json.MaxJsonLength = 500000000;
            return json;
            //return Json(OBJUsuarios, JsonRequestBehavior.AllowGet);
        }


        public JsonResult RetornaProvincias()
        {
            ///debemos desactivar la creación de objetos
            ///para evitar la creación de referencias circulares
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            ///realizar la consulta a la tabla de provincias
            List<Provincia> provincias =
                this.miModeloDB.Provincia.ToList();
            return Json(provincias, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Retorna los cantones tomando en cuenta el id de la provincia.
        /// </summary>
        /// <returns></returns>
        public ActionResult RetornaCantones(int id_Provincia)
        {
            ///debemos desactivar la creación de objetos
            ///para evitar la creación de referencias circulares
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            ///realizar la consulta a la tabla de cantones filtrando por el 
            ///id de la provincia
            List<Canton> cantones =
                this.miModeloDB.Canton.
                Where(m => m.id_Provincia == id_Provincia).ToList();

            return Json(cantones);
        }
        /// <summary>
        /// Retorna los distritos tomando en cuenta el id del cantón.
        /// </summary>
        /// <returns></returns>
        public ActionResult RetornaDistritos(int id_Canton)
        {
            ///debemos desactivar la creación de objetos
            ///para evitar la creación de referencias circulares
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            ///realizar la consulta a la tabla de cantones filtrando por el 
            ///id de la provincia
            List<Distrito> distritos =
                this.miModeloDB.Distrito.
                Where(m => m.id_Canton == id_Canton).ToList();

            return Json(distritos);
        }


        public ActionResult Perfil() {

            List<Usuarios> OBJUsuarios = miModeloDB.Usuarios.Where(m => m.idUsuarios == 4).ToList();
            return View(OBJUsuarios);

            
           /* var consulta = (from Usuarios in miModeloDB.Usuarios
                            join Provincias in miModeloDB.Provincia on Usuarios.FK_idProvincia equals Provincias.id_Provincia
                            select new
                            {
                                Cod = Usuarios.idUsuarios,
                                Nombre = Usuarios.Nombre,
                                Apellido1 = Usuarios.PrimerApellido,
                                Apellido2 = Usuarios.SegundoApellido,
                                Indentidicacion = Usuarios.NumeroIdentificacion,
                                Fotografia = Usuarios.Fotografia,
                                Provincia = Provincias.id_Provincia,
                            }).ToList();

            ViewBag.miModeloDB = consulta;*/

        }

        public ActionResult RegUsuarios()
        {

            return View();
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult RegUsuarios(Usuarios MiInsercion, Usuarios Fecha
            ,Provincia idProvincia,Canton idCanton,Distrito idDistrito,
            TipoUsuario idTipoUsuarios)//<---Parametros de insercion.
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    if (this.ValidarEmail(MiInsercion.CorreoElectronico))
                    {

                        HttpPostedFileBase archivoEnviado = this.Request.Files[0];
                        BinaryReader lectorBinario = new BinaryReader(archivoEnviado.InputStream);
                        byte[] resultado = lectorBinario.ReadBytes(archivoEnviado.ContentLength);
                        MiInsercion.Fotografia = resultado;

                        //var idM = idMaquina.idTipoMaquinaria;
                        //MiInsercion.FK_idMaquina = Convert.ToInt32(idM);
                        //var idE = idEjercicio.idTipoDeEjercicio;
                        //MiInsercion.FK_idEjercicio = Convert.ToInt32(idE);

                        var idTU = idTipoUsuarios.idTipoUsuario;
                        MiInsercion.FK_idTipoUsuario = Convert.ToInt32(idTU);
                        var id = idProvincia.id_Provincia;
                        MiInsercion.FK_idProvincia = Convert.ToInt32(id);
                        var idC = idCanton.id_Canton;
                        MiInsercion.FK_idCanton = Convert.ToInt32(idC);
                        var idD = idDistrito.id_Distrito;
                        MiInsercion.FK_idDistrito = Convert.ToInt32(idD);
                        var miFecha = Fecha.Fecha_Insercion;
                        miFecha = DateTime.Now;
                        MiInsercion.Fecha_Insercion = miFecha;
                       
                        string nombre;
                        nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                        MiInsercion.Usuario_Insercion = nombre;
                        miModeloDB.Usuarios.Add(MiInsercion);//<-----aqui agrego la sentencia para insertar 
                        miModeloDB.SaveChanges();
                        return RedirectToAction("index");
                    }
                    else
                    {
                        this.ModelState.AddModelError("", "Hubo un error  ");

                

                        // List<TipoDeMaquinaria> listaTipoDeMaquinaria = this.miModeloDB.TipoDeMaquinaria.ToList();
                        //ViewBag.ListaTipoDeMaquinaria = listaTipoDeMaquinaria;

                        //List<TipoDeEjercicio> listaTipoDeEjercicio = this.miModeloDB.TipoDeEjercicio.ToList();
                        // ViewBag.ListaTipoDeEjercicio = listaTipoDeEjercicio;

                    }
                }
            }
            catch(Exception Error) {
                this.ModelState.AddModelError("", "Existe un usuario con Email: "+Error);
          
            }
            return View();
        }

        /// <summary>
        /// Valida si un usuario posee el mismo email
        /// </summary>
        bool ValidarEmail(string PEmail)
        {
            bool resultado = false;
            Usuarios modeloBuscar = miModeloDB.Usuarios.SingleOrDefault<Usuarios>(m => m.CorreoElectronico == PEmail);
            if (modeloBuscar == null)
            {
                resultado = true;
                this.ModelState.AddModelError("", "Ya existe un usuario con el mismo email");
            }
            return resultado;
        }
        /*                    if (this.ValidarEmail(MiInsercion.CorreoElectronico))
                    { }
                    else { this.ModelState.AddModelError("", "Ya existe un usuario con el mismo email"); }*/


        public ActionResult EditarPerfil(int id)
        {

            Usuarios OBJUsuarios = miModeloDB.Usuarios.Find(id);
            return View(OBJUsuarios);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarPerfil(int id, Usuarios ModificarPerfil)
        {
            try
            {
                /*HttpPostedFileBase archivoEnviado = this.Request.Files[0];
                BinaryReader lectorBinario = new BinaryReader(archivoEnviado.InputStream);
                byte[] resultado = lectorBinario.ReadBytes(archivoEnviado.ContentLength);
                ModificarPerfil.Fotografia = resultado;*/
                Usuarios OBJUsuarios = miModeloDB.Usuarios.Find(id);
                miModeloDB.Entry(OBJUsuarios).CurrentValues.SetValues(ModificarPerfil);
                //Hacer el cmmit de la transaccion
                this.miModeloDB.SaveChanges();
                return RedirectToAction("Perfil");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult enviarEmail(int id) {

            Usuarios OBJUsuario = miModeloDB.Usuarios.Find(id);
            return View(OBJUsuario);

        }
       

        // GET: RegistroDeInstructores/Details/5
        public ActionResult VerDetalles(int id)
        {
            List<Usuarios> OBJUsuarios = miModeloDB.Usuarios.Where(m => m.idUsuarios == id).ToList();
            //Usuarios OBJUsuarios = miModeloDB.Usuarios.Find(id);
            return View(OBJUsuarios);
        }

        // GET: RegistroDeInstructores/Edit/5
        public ActionResult Edit(int id)
        {
            Usuarios OBJUsuarios = miModeloDB.Usuarios.Find(id);
            return View(OBJUsuarios);
        }

        // POST: RegistroDeInstructores/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Usuarios ModificarPerfil, Usuarios Fecha)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var miFecha = Fecha.Fecha_Modificacion;
                    miFecha = DateTime.Now;
                    ModificarPerfil.Fecha_Modificacion = miFecha;
                    string nombre;
                    nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                    ModificarPerfil.Usuario_Modificacion = nombre;
                    Usuarios OBJUsuarios = miModeloDB.Usuarios.Find(id);
                    miModeloDB.Entry(OBJUsuarios).CurrentValues.SetValues(ModificarPerfil);
                    //Hacer el cmmit de la transaccion
                    this.miModeloDB.SaveChanges();
                    return RedirectToAction("index");
                }
                return RedirectToAction("Index");
            }

            catch
            {
                return View();
            }
        }

        public Boolean ValidadRelacionesTablass(int id)
        {
            bool resultado = false;

            RegistroJugadores objetoModelo = miModeloDB.RegistroJugadores.Where(m => m.FK_idUsuarios == id).FirstOrDefault();
            if (objetoModelo != null)
            {
                return true;
            }

            return resultado;

        }



        //Eliminaar
        public ActionResult Delete(int id)
        {
            List<Usuarios> OBJUsuarios = miModeloDB.Usuarios.Where(m => m.idUsuarios == id).ToList();
            return View(OBJUsuarios);
        }

       
        [HttpPost]
        public ActionResult Delete(int id, Usuarios collection)
        {
            try
            {
                if (this.ValidadRelacionesTablass(id) == false)
                {

                    Usuarios OBJUsuarios = miModeloDB.Usuarios.Find(id);
                    miModeloDB.Usuarios.Remove(OBJUsuarios);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                else{
                    ModelState.AddModelError("", "No se puede eliminar ya que esta registrado como jugador.");
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }

        public ActionResult listaJugadores() {

            List<RegistroJugadores> miModelo = this.miModeloDB.RegistroJugadores.ToList();
            List<SP_selectInstructoress_Result> OBJUsuarioEncabezado = miModeloDB.SP_selectInstructoress().ToList();
            ViewBag.instructores = OBJUsuarioEncabezado;
            return View(miModelo);
        }



        public ActionResult nuevoJugador() {

            List<USUARIOS_DROP_DOWN_Result> ObtenerObtenerUsuarioJugador = this.miModeloDB.USUARIOS_DROP_DOWN().ToList();
            SelectList list = new SelectList(ObtenerObtenerUsuarioJugador, "idUsuarios", "Nombre");
            ViewBag.UsuarioJugador = list;


            return View();
        }

        [HttpPost]
        public ActionResult nuevoJugador(RegistroJugadores MiInsercion,Usuarios idUsuario, RegistroJugadores MiFecha)
        {
            try
            {

                    var miFecha = MiFecha.FechaDebud;
                    miFecha = DateTime.Now;
                    MiInsercion.FechaDebud = miFecha;
                    var id = idUsuario.idUsuarios;
                    MiInsercion.FK_idUsuarios = Convert.ToInt32(id);
                    miModeloDB.RegistroJugadores.Add(MiInsercion);//<-----aqui agrego la sentencia para insertar 
                    miModeloDB.SaveChanges();
                    return RedirectToAction("listaJugadores");

            }
            catch(Exception error)
            {
                return View();
            }


        }


        public Boolean ValidadRelacionesTablas(int id)
        {
            bool resultado = false;

            Encabezado objetoModelo = miModeloDB.Encabezado.Where(m => m.FK_idRegistroJugadores == id).FirstOrDefault();
            if (objetoModelo != null)
            {
                return true;
            }
            if (objetoModelo != null)
            {
                return true;
            }


            return resultado;

        }


        public ActionResult Eliminar(int id) {

            List<SP_ObtenerJugador_ID_Result> miModelo = this.miModeloDB.SP_ObtenerJugador_ID(id).ToList();
            return View(miModelo);
        }

        [HttpPost]
        public ActionResult Eliminar(int id, RegistroJugadores collection)
        {

            try
            {
                if (this.ValidadRelacionesTablas(id) == false)
                {
                    RegistroJugadores OBJRegistroJugadores = miModeloDB.RegistroJugadores.Find(id);
                    miModeloDB.RegistroJugadores.Remove(OBJRegistroJugadores);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("listaJugadores");
                }
                else {
                    ModelState.AddModelError("", "No se puede eliminar ya que tiene un encabezado registrado con este jugador.");
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }


        public ActionResult nuevoInstructor()
        {

            List<USUARIOS_DROP_DOWN_Result> ObtenerUsuarioInstructor = this.miModeloDB.USUARIOS_DROP_DOWN().ToList();
            SelectList list = new SelectList(ObtenerUsuarioInstructor, "idUsuarios", "Nombre");
            ViewBag.ObtenerUsuarioInstructores = list;


            return View();
        }


        [HttpPost]
        public ActionResult nuevoInstructor(RegistroDeInstructores MiInsercion, Usuarios idUsuario, RegistroDeInstructores MiFecha)
        {
            try
            {

                var miFecha = MiFecha.Fecha_Insercion;
                miFecha = DateTime.Now;
                MiInsercion.Fecha_Insercion = miFecha;
                var id = idUsuario.idUsuarios;
                MiInsercion.FK_idUsuarios = Convert.ToInt32(id);
                miModeloDB.RegistroDeInstructores.Add(MiInsercion);//<-----aqui agrego la sentencia para insertar 
                miModeloDB.SaveChanges();
                return RedirectToAction("listaJugadores");

            }
            catch (Exception error)
            {
                return View();
            }


        }


        public Boolean ValidadRelacionesTablasss(int id)
        {
            bool resultado = false;

            Encabezado objetoModelo = miModeloDB.Encabezado.Where(m => m.FK_idRegistroDeInstructores == id).FirstOrDefault();
            if (objetoModelo != null)
            {
                return true;
            }
            if (objetoModelo != null)
            {
                return true;
            }


            return resultado;

        }


        public ActionResult EliminarInstructor(int id)
        {

            List<SP_selectInstructoress_ID_Result> miModelo = this.miModeloDB.SP_selectInstructoress_ID(id).ToList();
            return View(miModelo);
        }

        [HttpPost]
        public ActionResult EliminarInstructor(int id, RegistroDeInstructores collection)
        {

            try
            {
                if (this.ValidadRelacionesTablasss(id) == false)
                {
                    RegistroDeInstructores OBJRegistroJugadores = miModeloDB.RegistroDeInstructores.Find(id);
                    miModeloDB.RegistroDeInstructores.Remove(OBJRegistroJugadores);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("listaJugadores");
                }
                else
                {
                    ModelState.AddModelError("", "No se puede eliminar ya que tiene un encabezado registrado con este instructor.");
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }



    }
}
