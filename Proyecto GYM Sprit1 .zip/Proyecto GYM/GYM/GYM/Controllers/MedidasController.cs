﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GYM.BD;

namespace ProyectoProgra6.Controllers
{
    public class MedidasController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();

        // GET: Medidas
        public ActionResult Index()
        {   
            List<Medidas> miModelo = this.miModeloDB.Medidas.ToList();
            return View(miModelo);
        }

        // GET: Medidas/Details/5
        public ActionResult Details(int id)
        {
            Medidas OBJMedidas = miModeloDB.Medidas.Find(id);
            return View(OBJMedidas);
        }


        public ActionResult FormularioMedidas()
        {

            ViewBag.TipoDeMedidas1 = this.miModeloDB.TipoDeMedidas1().ToList();
            return View();
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult FormularioMedidas(Medidas MiInsercion,Medidas Fecha,Medidas Estados, TipoDeMedidas idTipoMedida)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {   


                    var id = idTipoMedida.idTipoDeMedidas;
                    MiInsercion.FK_idTipoDeMedidas = Convert.ToInt32(id);
                    var Estadoss = Estados.Estado;
                    MiInsercion.Estado = Convert.ToString(Estadoss);
                    var miFecha = Fecha.Fecha_Insercion;
                    miFecha = DateTime.Now;
                    MiInsercion.Fecha_Insercion = miFecha;
                    string nombre;
                    nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                    MiInsercion.Usuario_Insercion = nombre;
                    miModeloDB.Medidas.Add(MiInsercion);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }
            catch
            {
                ViewBag.TipoDeMedidas1 = this.miModeloDB.TipoDeMedidas1().ToList();
                return View();
            }
        }





        // GET: Medidas/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Medidas/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Medidas/Edit/5
        public ActionResult Edit(int id)
        {
            Medidas OBJMedidas = miModeloDB.Medidas.Find(id);
            return View(OBJMedidas);
        }

        // POST: Medidas/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Medidas MoEditar, Medidas MoUsuario, Medidas Fecha)
        {
            try
            {
                var miFecha = Fecha.Fecha_Modificacion;
                miFecha = DateTime.Now;
                MoEditar.Fecha_Modificacion = miFecha;
                string nombre;
                nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                MoEditar.Usuario_Modificacion = nombre;
                Medidas OBJMedidas = miModeloDB.Medidas.Find(id);
                miModeloDB.Entry(OBJMedidas).CurrentValues.SetValues(MoEditar);
                //Hacer el cmmit de la transaccion
                this.miModeloDB.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            List<Medidas> OBJMedidas = miModeloDB.Medidas.Where(m => m.idMedidas == id).ToList();
            return View(OBJMedidas);
        }

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                Medidas OBJMedidas = miModeloDB.Medidas.Find(id);
                miModeloDB.Medidas.Remove(OBJMedidas);
                miModeloDB.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
