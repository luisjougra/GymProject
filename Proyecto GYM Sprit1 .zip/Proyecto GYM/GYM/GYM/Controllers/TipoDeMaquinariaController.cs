﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GYM.BD;

namespace ProyectoProgra6.Controllers
{
    public class TipoDeMaquinariaController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();

        // GET: TipoDeMaquinaria
        public ActionResult Index()
        {
            List<TipoDeMaquinaria> miConsulta = this.miModeloDB.TipoDeMaquinaria.ToList();
            return View(miConsulta);
        }


        public ActionResult FormularioTipoMaquina()
        {
            return View();
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult FormularioTipoMaquina(TipoDeMaquinaria MiInsercion, TipoDeMaquinaria Fecha)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    string nombre;
                    nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                    MiInsercion.Usuario_Insercion = nombre;
                    var miFecha = Fecha.Fecha_Insercion;
                    miFecha = DateTime.Now;
                    MiInsercion.Fecha_Insercion = miFecha;
                    miModeloDB.TipoDeMaquinaria.Add(MiInsercion);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }



        // GET: TipoDeMaquinaria/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: TipoDeMaquinaria/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TipoDeMaquinaria/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: TipoDeMaquinaria/Edit/5
        public ActionResult Edit(int id)
        {
            TipoDeMaquinaria OBJTipoDeMaquinaria = miModeloDB.TipoDeMaquinaria.Find(id);
            return View(OBJTipoDeMaquinaria);
        }

        // POST: TipoDeMaquinaria/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, TipoDeMaquinaria MoEditar, TipoDeMaquinaria Fecha)
        {
            try
            {
                var miFecha = Fecha.Fecha_Modificacion;
                miFecha = DateTime.Now;
                MoEditar.Fecha_Modificacion = miFecha;
                string nombre;
                nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                MoEditar.Usuario_Modificacion = nombre;
                TipoDeMaquinaria OBJTipoDeMaquinaria = miModeloDB.TipoDeMaquinaria.Find(id);
                miModeloDB.Entry(OBJTipoDeMaquinaria).CurrentValues.SetValues(MoEditar);
                //Hacer el cmmit de la transaccion
                this.miModeloDB.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        public Boolean ValidadRelacionesTablas(int id)
        {
            bool resultado = false;

            Maquina objetoModelo = miModeloDB.Maquina.Where(m => m.FK_TipoMaquinaria == id).FirstOrDefault();
            if (objetoModelo != null)
            {
                return true;
            }
            if (objetoModelo != null)
            {
                return true;
            }


            return resultado;

        }


        public ActionResult Delete(int id)
        {
            List<TipoDeMaquinaria> OBJTipoDeMaquinaria = miModeloDB.TipoDeMaquinaria.Where(m => m.idTipoMaquinaria == id).ToList();
            return View(OBJTipoDeMaquinaria);
        }

 
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                if (this.ValidadRelacionesTablas(id) == false)
                {

                    // TODO: Add delete logic here
                    TipoDeMaquinaria OBJTipoDeMaquinaria = miModeloDB.TipoDeMaquinaria.Find(id);
                    miModeloDB.TipoDeMaquinaria.Remove(OBJTipoDeMaquinaria);
                    miModeloDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                else {
                    ModelState.AddModelError("", "No se puede eliminar ya que tiene una maquina con este valor.");
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }



    }
}
