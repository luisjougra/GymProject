﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using GYM.BD;
using GYM.Models;

namespace GYM.Controllers
{
    public class RegistroJugadoresController : Controller
    {
        GYMEntities miModeloDB = new GYMEntities();
        // GET: RegistroJugadores
        public ActionResult Index()
        {
            List<Usuarios> USUARIO_JUGADOR = this.miModeloDB.Usuarios.Where(m => m.FK_idTipoUsuario == 3).ToList();
            return View(USUARIO_JUGADOR);
        }
        public int MaxJsonLength { get; set; }

        public JsonResult RetornaUsuarios()
        {
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            List<Usuarios> USUARIO_JUGADOR = this.miModeloDB.Usuarios.Where(m => m.FK_idTipoUsuario == 3).ToList();
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            serializer.MaxJsonLength = 500000000;
            var json = Json(USUARIO_JUGADOR, JsonRequestBehavior.AllowGet);
            json.MaxJsonLength = 500000000;
            return json;
            //return Json(OBJUsuarios, JsonRequestBehavior.AllowGet);
        }


        public JsonResult RetornaProvincias()
        {
            ///debemos desactivar la creación de objetos
            ///para evitar la creación de referencias circulares
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            ///realizar la consulta a la tabla de provincias
            List<Provincia> provincias =
                this.miModeloDB.Provincia.ToList();
            return Json(provincias, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Retorna los cantones tomando en cuenta el id de la provincia.
        /// </summary>
        /// <returns></returns>
        public ActionResult RetornaCantones(int id_Provincia)
        {
            ///debemos desactivar la creación de objetos
            ///para evitar la creación de referencias circulares
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            ///realizar la consulta a la tabla de cantones filtrando por el 
            ///id de la provincia
            List<Canton> cantones =
                this.miModeloDB.Canton.
                Where(m => m.id_Provincia == id_Provincia).ToList();

            return Json(cantones);
        }
        /// <summary>
        /// Retorna los distritos tomando en cuenta el id del cantón.
        /// </summary>
        /// <returns></returns>
        public ActionResult RetornaDistritos(int id_Canton)
        {
            ///debemos desactivar la creación de objetos
            ///para evitar la creación de referencias circulares
            miModeloDB.Configuration.ProxyCreationEnabled = false;
            ///realizar la consulta a la tabla de cantones filtrando por el 
            ///id de la provincia
            List<Distrito> distritos =
                this.miModeloDB.Distrito.
                Where(m => m.id_Canton == id_Canton).ToList();

            return Json(distritos);
        }




        public ActionResult RegUsuariosJugadores()
        {
           
   

            return View();
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult RegUsuariosJugadores(Usuarios MiInsercion, Usuarios Fecha
            , Provincia idProvincia, Canton idCanton, Distrito idDistrito,
            TipoUsuario idTipoUsuarios)//<---Parametros de insercion.
        {
            try
            {
                // TODO: Add insert logic here

                        HttpPostedFileBase archivoEnviado = this.Request.Files[0];
                        BinaryReader lectorBinario = new BinaryReader(archivoEnviado.InputStream);
                        byte[] resultado = lectorBinario.ReadBytes(archivoEnviado.ContentLength);
                        MiInsercion.Fotografia = resultado;

                        var idTU = 3;
                        MiInsercion.FK_idTipoUsuario = Convert.ToInt32(idTU);
                        var id = idProvincia.id_Provincia;
                        MiInsercion.FK_idProvincia = Convert.ToInt32(id);
                        var idC = idCanton.id_Canton;
                        MiInsercion.FK_idCanton = Convert.ToInt32(idC);
                        var idD = idDistrito.id_Distrito;
                        MiInsercion.FK_idDistrito = Convert.ToInt32(idD);
                        var miFecha = Fecha.Fecha_Insercion;
                        miFecha = DateTime.Now;
                        MiInsercion.Fecha_Insercion = miFecha;

                        string nombre;
                        nombre = Convert.ToString(this.Session["nombreCompleto"].ToString());
                        MiInsercion.Usuario_Insercion = nombre;
                        miModeloDB.Usuarios.Add(MiInsercion);//<-----aqui agrego la sentencia para insertar 
                        miModeloDB.SaveChanges();
                        return RedirectToAction("index");

            }
            catch (Exception Error)
            {
                this.ModelState.AddModelError("", "Se produjo una Excepción: " + Error);

            }
            return View();
        }


        bool ValidarEmail(string PEmail)
        {
            bool resultado = false;
            Usuarios modeloBuscar = miModeloDB.Usuarios.SingleOrDefault<Usuarios>(m => m.CorreoElectronico == PEmail);
            if (modeloBuscar == null)
            {
                resultado = true;
                this.ModelState.AddModelError("", "Ya existe un usuario con el mismo email");
            }
            return resultado;
        }











    }
}